import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.tusmind.Events
import com.example.tusmind.HomeScreen
import com.example.tusmind.MayorstoneMapUI
import com.example.tusmind.OutdoorActivitiesScreen
import com.example.tusmind.SetTimeScreen
import com.example.tusmind.ShelbourneMapUI
import com.example.tusmind.TimerScreen
import com.example.tusmind.WalkSelectionScreen
import com.example.tusmind.WelcomeScreen

@Composable
fun AppNavigation(navController: NavHostController) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "welcome"
    ) {
        composable("welcome") { WelcomeScreen(navController) }
        composable("home") { HomeScreen(navController) }
        composable("set_time") { SetTimeScreen(navController) }
        composable(
            "timer/{selectedTime}",
            arguments = listOf(navArgument("selectedTime") { type = NavType.IntType })
        ) { backStackEntry ->
            val selectedTime = backStackEntry.arguments?.getInt("selectedTime") ?: 5
            val initialTime = if (selectedTime == 5) 300 else 600 // Convert to seconds

            val timerViewModel: TimerViewModel = viewModel(
                key = "TimerViewModel_${initialTime}",
                factory = object : ViewModelProvider.Factory {
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        if (modelClass.isAssignableFrom(TimerViewModel::class.java)) {
                            return TimerViewModel(backStackEntry.savedStateHandle, initialTime) as T
                        }
                        throw IllegalArgumentException("Unknown ViewModel class")
                    }
                }
            )

            TimerScreen(navController, timerViewModel, selectedTime) // Pass selectedTime
        }

        composable("events") { Events(navController) }
        composable("outdoor_activities") { OutdoorActivitiesScreen(navController) }
        composable("mayorstone_map") { MayorstoneMapUI(navController) }
        composable("shelbourne_map") { ShelbourneMapUI(navController) }
        composable("walk-selection") { WalkSelectionScreen(navController) }
        composable("mayorstone") { MayorstoneMapUI(navController) }
        composable("shelbourne") { ShelbourneMapUI(navController) }

    }
}
