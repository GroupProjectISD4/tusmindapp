package com.example.tusmind

import TimerViewModel
import android.media.MediaPlayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController

@Composable
fun TimerScreen(navController: NavHostController, viewModel: TimerViewModel, selectedTime: Int) {
    var selectedMeditation by remember { mutableStateOf("Select Meditation") }
    var isDropdownExpanded by remember { mutableStateOf(false) }


    //References for all meditations audios:
    //https://www.freemindfulness.org/download
    val fiveMinuteMeditations = listOf(
        "MARC 5 Minute Breathing",
        "Life Happens 5 Minute Breathing",
        "Free Mindfulness 5 Minute Just Bells",
        "Vidyamala Tension Release"
    )

    val tenMinuteMeditations = listOf(
        "Breathworks Body Scan",
        "Padraig 10 Minute Mindfulness of Breathing",
        "Free Mindfulness Mountain Meditation",
        "MARC Breath Sound Body Meditation",
        "10 minute Wisdom Meditation",
        "Vidyamala Compassionate Breath"
    )

    val displayedMeditations = if (selectedTime == 5) fiveMinuteMeditations else tenMinuteMeditations

    var mediaPlayer: MediaPlayer? by remember { mutableStateOf(null) }

    // Handle MediaPlayer lifecycle based on selected meditation
    LaunchedEffect(selectedMeditation) {
        mediaPlayer?.release()
        mediaPlayer = if (selectedMeditation != "Select Meditation") {
            MediaPlayer.create(navController.context, getMeditationResource(selectedMeditation))
        } else null

    }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        // Background image
        Image(
            painter = painterResource(id = R.drawable.bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {


            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White,
                    modifier = Modifier
                        .size(24.dp)
                        .clickable {
                            navController.popBackStack() // Navigate back
                        }
                )
                Spacer(modifier = Modifier.width(36.dp))
            }
            // Dropdown for selecting meditations
            Column(

                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = { isDropdownExpanded = !isDropdownExpanded },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF30766E))
                ) {
                    Text(text = selectedMeditation)
                }
                DropdownMenu(
                    expanded = isDropdownExpanded,
                    onDismissRequest = { isDropdownExpanded = false }
                ) {
                    displayedMeditations.forEach { meditation ->
                        DropdownMenuItem(
                            text = { Text(meditation) },
                            onClick = {
                                selectedMeditation = meditation
                                isDropdownExpanded = false
                            }
                        )
                    }
                }
            }
            // Circular Timer
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(200.dp)
                ) {
                    androidx.compose.material3.CircularProgressIndicator(
                        progress = viewModel.progress.value,
                        strokeWidth = 8.dp,
                        color = Color.White,
                        modifier = Modifier.fillMaxSize()
                    )
                    Text(
                        text = String.format(
                            "%02d:%02d",
                            viewModel.timeLeft.value / 60,
                            viewModel.timeLeft.value % 60
                        ),
                        style = TextStyle(
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Start / Pause Button
                StartPauseButton(
                    isRunning = viewModel.isRunning.value,
                    isPaused = viewModel.isPaused.value,
                    onStart = {
                        viewModel.startTimer()
                        mediaPlayer?.start()
                    },
                    onPause = {
                        viewModel.pauseTimer()
                        mediaPlayer?.pause()
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Restart Button
                RestartButton(onRestart = {
                    viewModel.restartTimer()
                    mediaPlayer?.seekTo(0)
                    mediaPlayer?.pause()
                })
            }

            // Bottom Navigation Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, // Distribute icons evenly
                verticalAlignment = Alignment.CenterVertically
            ) {

                // Outdoor Icon
                Icon(
                    imageVector = Icons.Filled.LocationOn,
                    contentDescription = "Outdoor",
                    tint = Color.White,
                    modifier = Modifier.clickable {
                        navController.navigate("outdoor_activities") // Navigate to Outdoor screen
                    }
                )
                // Home Icon
                Icon(
                    imageVector = Icons.Filled.Home,
                    contentDescription = "Home",
                    tint = Color.White,
                    modifier = Modifier.clickable {
                        navController.navigate("home") // Navigate to Home screen
                    }
                )
                // events Icon
                Icon(
                    imageVector = Icons.Filled.DateRange,
                    contentDescription = "Events",
                    tint = Color.White,
                    modifier = Modifier.clickable {
                        navController.navigate("events") // Navigate to events screen
                    }
                )
            }
        }
    }
}

@Composable
fun StartPauseButton(
    isRunning: Boolean,
    isPaused: Boolean,
    onStart: () -> Unit,
    onPause: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(
                color = Color(0xFF1D1D1D), // Button color
                shape = RoundedCornerShape(12.dp)
            )
            .clickable {
                if (!isRunning) onStart() else onPause()
            }
            .padding(horizontal = 32.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (!isRunning) "Start" else "Pause",
            style = TextStyle(
                fontSize = 18.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

@Composable
fun RestartButton(onRestart: () -> Unit) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .background(
                color = Color(0xFF1D1D1D), // Button color
                shape = RoundedCornerShape(28.dp) // Circular button
            )
            .clickable { onRestart() }, // Trigger restart logic
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Filled.Refresh,
            contentDescription = "Restart",
            tint = Color.White,
            modifier = Modifier.size(28.dp)
        )
    }
}

// Helper function to map meditation names to resources
fun getMeditationResource(name: String): Int {
    return when (name) {
        "MARC 5 Minute Breathing" -> R.raw.marc5minutebreathing
        "Life Happens 5 Minute Breathing" -> R.raw.lifehappens5minutebreathing
        "Free Mindfulness 5 Minute Just Bells" -> R.raw.freemindfulness5minutejustbells
        "Vidyamala Tension Release" -> R.raw.vidyamalatensionrelease
        "Breathworks Body Scan" -> R.raw.breathworksbodyscan
        "Padraig 10 Minute Mindfulness of Breathing" -> R.raw.padraigtenminutemindfulnessofbreathing
        "Free Mindfulness Mountain Meditation" -> R.raw.freemindfulnessmountainmeditation
        "MARC Breath Sound Body Meditation" -> R.raw.marcbreathsoundbodymeditation
        "10 minute Wisdom Meditation" -> R.raw.tenminutewisdommeditation
        "Vidyamala Compassionate Breath" -> R.raw.vidyamalacompassionatebreath
        else -> 0
    }
}



@Preview(showBackground = true)
@Composable
fun TimerScreenPreview() {
    val navController = rememberNavController()
    val mockViewModel = TimerViewModel(
        savedStateHandle = androidx.lifecycle.SavedStateHandle(mapOf("initialTime" to 300)),
        initialTime = 300
    )
    TimerScreen(
        navController = navController,
        viewModel = mockViewModel,
        selectedTime = 5 // Default to 5 minutes for the preview
    )
}
