import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableStateOf

class TimerViewModel(
    private val savedStateHandle: SavedStateHandle,
    initialTime: Int
) : ViewModel() {

    val timeLeft = mutableStateOf(savedStateHandle["timeLeft"] ?: initialTime)
    val progress = mutableStateOf(savedStateHandle["progress"] ?: 1f)
    val isRunning = mutableStateOf(savedStateHandle["isRunning"] ?: false)
    val isPaused = mutableStateOf(savedStateHandle["isPaused"] ?: false)

    private var totalTime = savedStateHandle["totalTime"] ?: initialTime

    init {
        savedStateHandle["timeLeft"] = timeLeft.value
        savedStateHandle["progress"] = progress.value
        savedStateHandle["totalTime"] = totalTime
    }

    fun startTimer() {
        if (!isRunning.value || isPaused.value) {
            isRunning.value = true
            isPaused.value = false
            savedStateHandle["isRunning"] = true
            savedStateHandle["isPaused"] = false
            viewModelScope.launch {
                while (isRunning.value && !isPaused.value && timeLeft.value > 0) {
                    delay(1000L)
                    timeLeft.value -= 1
                    progress.value = timeLeft.value / totalTime.toFloat()
                    // Save state in SavedStateHandle
                    savedStateHandle["timeLeft"] = timeLeft.value
                    savedStateHandle["progress"] = progress.value
                }
            }
        }
    }

    fun pauseTimer() {
        isRunning.value = false
        isPaused.value = true
        savedStateHandle["isRunning"] = false
        savedStateHandle["isPaused"] = true
    }

    fun restartTimer() {
        timeLeft.value = totalTime
        progress.value = 1f
        isRunning.value = false
        isPaused.value = false
        savedStateHandle["timeLeft"] = totalTime
        savedStateHandle["progress"] = 1f
        savedStateHandle["isRunning"] = false
        savedStateHandle["isPaused"] = false
    }
}
