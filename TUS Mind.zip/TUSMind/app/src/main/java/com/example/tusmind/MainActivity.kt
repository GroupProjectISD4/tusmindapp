package com.example.tusmind

import AppNavigation
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.rememberNavController
import com.example.tusmind.ui.theme.TUSMindTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // Ensure edge-to-edge design

        setContent {
            TUSMindTheme {
                // Initialize NavController
                val navController = rememberNavController()

                // Set up the navigation host
                AppNavigation(navController)
            }
        }
    }
}
